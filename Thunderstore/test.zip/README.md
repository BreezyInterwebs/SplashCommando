# Trovian

This mod creates alternate Commando skills based off the *Gunslinger* from *Trove.*

Because this is my first (and maybe only) mod, it uses prefabbed materials from base RoR2.
And is probably coded terribly.

And is probably a little too powerful.

## Skills

### Secondary: Charge Shot
Fires a charged shot for 700 % damage.
This charged shot alternates between two projectiles.

### Utility: Blast Jump
Jump into the sky.

### Special: Overcharge
Fires a 5 second burst of Charge Shots.
Can be interrupted by Blast Jump.

### Passive: Velocity Leecher
Doing damage slows your fall. You can prevent fall damage if enemies exist!

### Passive: No Passive
Lets you play normal Commando.
